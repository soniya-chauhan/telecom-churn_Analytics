USE churn_analysis;

SELECT COUNT(*) AS total_customers
FROM customer_churn;

DESCRIBE customer_churn;

SELECT
    COUNT(*) AS total_rows,
    SUM(customerID IS NULL) AS missing_customerID,
    SUM(gender IS NULL) AS missing_gender,
    SUM(SeniorCitizen IS NULL) AS missing_SeniorCitizen,
    SUM(Partner IS NULL) AS missing_Partner,
    SUM(Dependents IS NULL) AS missing_Dependents,
    SUM(tenure IS NULL) AS missing_tenure,
    SUM(PhoneService IS NULL) AS missing_PhoneService,
    SUM(MultipleLines IS NULL) AS missing_MultipleLines,
    SUM(InternetService IS NULL) AS missing_InternetService,
    SUM(OnlineSecurity IS NULL) AS missing_OnlineSecurity,
    SUM(OnlineBackup IS NULL) AS missing_OnlineBackup,
    SUM(DeviceProtection IS NULL) AS missing_DeviceProtection,
    SUM(TechSupport IS NULL) AS missing_TechSupport,
    SUM(StreamingTV IS NULL) AS missing_StreamingTV,
    SUM(StreamingMovies IS NULL) AS missing_StreamingMovies,
    SUM(Contract IS NULL) AS missing_Contract,
    SUM(PaperlessBilling IS NULL) AS missing_PaperlessBilling,
    SUM(PaymentMethod IS NULL) AS missing_PaymentMethod,
    SUM(MonthlyCharges IS NULL) AS missing_MonthlyCharges,
    SUM(TotalCharges IS NULL) AS missing_TotalCharges,
    SUM(Churn IS NULL) AS missing_Churn
FROM customer_churn;

SELECT COUNT(*) AS blank_total_charges
FROM customer_churn
WHERE TRIM(TotalCharges) = '';

SELECT
    COUNT(*) AS total_rows,
    COUNT(DISTINCT customerID) AS unique_customers
FROM customer_churn;

SELECT
    Churn,
    COUNT(*) AS customer_count,
    ROUND(COUNT(*) * 100.0 / (SELECT COUNT(*) FROM customer_churn), 2) AS churn_percentage
FROM customer_churn
GROUP BY Churn;

SELECT Contract, Churn, COUNT(*) AS customers
FROM customer_churn
GROUP BY Contract, Churn;

SELECT
    Contract,
    ROUND(SUM(Churn = 'Yes') * 100.0 / COUNT(*), 2) AS churn_rate
FROM customer_churn
GROUP BY Contract;

SELECT
    InternetService,
    ROUND(SUM(Churn = 'Yes') * 100.0 / COUNT(*), 2) AS churn_rate
FROM customer_churn
GROUP BY InternetService;

SELECT
    PaymentMethod,
    ROUND(SUM(Churn = 'Yes') * 100.0 / COUNT(*), 2) AS churn_rate
FROM customer_churn
GROUP BY PaymentMethod;

SELECT
    CASE
        WHEN tenure <= 12 THEN '0-1 year'
        WHEN tenure <= 24 THEN '1-2 years'
        WHEN tenure <= 48 THEN '2-4 years'
        ELSE '4+ years'
    END AS tenure_group,
    ROUND(SUM(Churn = 'Yes') * 100.0 / COUNT(*), 2) AS churn_rate
FROM customer_churn
GROUP BY tenure_group;

SELECT
    Churn,
    ROUND(AVG(MonthlyCharges), 2) AS avg_monthly_charges
FROM customer_churn
GROUP BY Churn;

SELECT
    SeniorCitizen,
    Churn,
    COUNT(*) AS customers
FROM customer_churn
GROUP BY SeniorCitizen, Churn;

SELECT
    gender,
    Churn,
    COUNT(*) AS customers
FROM customer_churn
GROUP BY gender, Churn;

SELECT
    Partner,
    Churn,
    COUNT(*) AS customers
FROM customer_churn
GROUP BY Partner, Churn;

SELECT
    Dependents,
    Churn,
    COUNT(*) AS customers
FROM customer_churn
GROUP BY Dependents, Churn;

SELECT
    Churn,
    ROUND(AVG(TotalCharges), 2) AS avg_total_charges
FROM customer_churn
GROUP BY Churn;

SELECT
    COUNT(*) AS total_customers,
    SUM(Churn = 'Yes') AS churned_customers,
    ROUND(SUM(Churn = 'Yes') * 100.0 / COUNT(*), 2) AS churn_rate,
    ROUND(AVG(tenure), 2) AS avg_tenure,
    ROUND(AVG(MonthlyCharges), 2) AS avg_monthly_charges
FROM customer_churn;